var initConstant = {
    //流程
    step: 1,
    //{number} 0 经纬度模式 1 删格图模式
    dataMode: 0,
    //地图的缩放级别
    zoom : null
}
