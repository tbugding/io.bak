//页面dom
var Dom = {}
function initDom() {
    Dom = {
        left: $("#left"),
        right: $("#right"),
        attachToMap: $("#attachToMap"),
        changLevel: $("#changLevel"),
        strict: $("#strict"),
        cbCenter: $("#cbCenter"),
        BtnExport: $("#BtnExport"),
        BtnCorrect: $("#BtnCorrect"),
        showLevel: $("#showLevel"),
        delTable: $("#delTable"),
        mbData: $("#mbData"),
        resultToCopy: $("#resultTocopy"),
        btnValidation: $("#btnValidation"),
        feedBackToCopy: $("#feedBackTocopy"),
        dataLi: $(".dataLi"),
        chooseFormat: $(".arrow-down"),
        latLngData: $("#latLngT"),
        photoData: $("#photoT"),
        paramT: $(".paramT"),
        dataTopLi: $(".dataTop li"),
        letd: $('.letd'),
        fRe:$(".fRe")
    }
};