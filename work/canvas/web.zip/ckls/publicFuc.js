var publicFuc = {
    analyze : function () {
        treeTable.setDom($("#browser"));
        treeTable.setDataDrive(dataDrive);
        treeTable.fill();
    }
}